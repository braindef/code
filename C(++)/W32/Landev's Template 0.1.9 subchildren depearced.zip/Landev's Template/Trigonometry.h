#ifndef Trigonometry_h
#define Trigonometry_h

//                 n  
// sin(x) = lim (  ? (-1)^k x^(2*k+1)/(2*k+1)! )
//          n->8  k=0

//                 n  
// cos(x) = lim (  ? (-1)^k x^(2*k)/(2*k)! )
//          n->8  k=0

//          
// tan(x) = naja sagen wir einfach sin(x)/cos(x) hehe...
//          

// Pi = 4 * tan(1.0)

#endif


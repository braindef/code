#include "Engine.h"
#include <vector>


LPDIRECT3DDEVICE9* landev::Engine::parentRenderingDevice=NULL;


HWND myhwnd;

HANDLE mutex;					//f�r jedes objekt ein eigenes mutex



DWORD WINAPI GlobalModelThread(LPVOID *param)
{
	while(true)
	{
		WaitForSingleObject (mutex, 1000);
		MessageBox(myhwnd, "Habe Mutex", "Mutex", NULL);

		

		ReleaseMutex (mutex);
		Sleep(1000);

	}
	return 0;
}





landev::Engine::Engine(LPDIRECT3DDEVICE9* parentDevice)
{
	if (parentRenderingDevice!=NULL) parentRenderingDevice = parentDevice;
	init=true;
	landev::Engine::modelStartTime=GetTickCount();	

	mutex = CreateMutex (NULL, false, NULL);

	DWORD dwID;
	HANDLE threadHandle = CreateThread(	NULL,							// default security attributes 
										0x1000,							// 0 : use default stack size
										(LPTHREAD_START_ROUTINE)GlobalModelThread,	// thread function 
										NULL,							// argument to thread function
										NULL,							// 0 : use default creation flags or CREATE_SUSPENDED
										&dwID );						// returns the thread identifier
																			// in objekt 3. letztes parameter (LPVOID)this


}

HRESULT landev::Engine::HookChild(landev::Engine* child)
{
	children.push_back(child);
	childrenCount++;

	return S_OK; //allenfalls noch schauen ob es wirklich auch funktioniert hat, vs. rechenaufwand...
}


HRESULT landev::Engine::Draw()
{
	return Draw(0, 0, 640, 480);
}

HRESULT landev::Engine::Draw(int x, int y, int width, int height)
{
	//Hier die Szenen hinzuf�gen

	WaitForSingleObject (mutex, 1000);		// Auf Single object warten, unkritisch solange berechnungen nicht > .05 sek sonst wartet der Frame loop sinnlos
	
	for(unsigned int i=0; i<children.size(); i++)
	{
		landev::Engine* object = children[i];
		object->Draw();

	}
	
	ReleaseMutex (mutex);					// Das Mutex freigeben
	
	init=false;
	return S_OK;
}





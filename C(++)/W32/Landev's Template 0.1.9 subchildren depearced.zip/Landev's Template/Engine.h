#ifndef Engine_h
#define Engine_h


#include "d3d9.h"
#include "d3dx9shape.h"
#include "DX9Window.h"
#include <vector>

#include "FPS.h"

#include "math.h"			//sin
//#include "stdio.h"			//sprintf


namespace landev
{
	namespace anotherNamespace
	{
		class anotherClass
		{
		};
	}

	class Engine
	{
	public:

		//Device
		static LPDIRECT3DDEVICE9* parentRenderingDevice;
		Engine(LPDIRECT3DDEVICE9* parentDevice);

		//Methods and Atributes
		bool init;
		HRESULT Draw();
		HRESULT Draw(int x, int y, int width, int height);

		//References to other objects
		HRESULT HookChild(Engine* child);
		Engine* parent;
		int childrenCount;
		std::vector<landev::Engine*> children;

		//Threading

		//Thread.Start
		//Thread.Stop
		//Thread.destruct
		

		int modelStartTime;
		int modelTime;
	};
}


#endif
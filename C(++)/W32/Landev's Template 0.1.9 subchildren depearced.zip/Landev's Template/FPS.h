#ifndef FPS_h
#define FPS_h

#include "d3d9.h"
#include "d3dx9shape.h"

#include "stdio.h"			//sprintf

namespace landev
{
	class FPS
	{
	public:
		
		
		char* FPSString;
		ID3DXFont* FPSText;
		RECT FPSRect;

		int LastFrame;
		int FrameTime;
		FPS(LPDIRECT3DDEVICE9* parentDevice, int x, int y);
		
		void Draw();
		void Draw(int x, int y);
	};
}


#endif
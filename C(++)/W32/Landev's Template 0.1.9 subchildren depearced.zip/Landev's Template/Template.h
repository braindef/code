#ifndef Template_h
#define Template_h

// Beispiel f�r ein Template 
//
// template <class Typenbezeichner> Funktionsdefinition
//

#endif

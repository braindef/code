#include <stdio.h>
#include <windows.h>
//#include <Commctrl.h>
#include "resource.h"
#include "K8055D_C.h"

#include "d3d9.h"

#pragma comment(lib, "d3d9.lib") 
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "K8055D_C.lib")
#pragma comment(lib, "winmm.lib")


#define START_BEEP 1
#define STOP_BEEP 2
#define INTERRUPT_BEEP 3
#define VALID_BEEP 4
#define INVALID_BEEP 5
#define END_BEEP 6
#define PREWARN_BEEP 7
#define CONTINUE_BEEP 8






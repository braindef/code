#ifndef DX9Window_h
#define DX9Window_h

#pragma comment(lib, "d3d9.lib") 
#pragma comment(lib, "d3dx9.lib") 
#pragma comment(lib, "dxguid.lib")

#pragma comment(lib, "d3dxof.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "d3dx9dt.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "winmm.lib")


#include "d3d9.h"


namespace landev 
{
	class DX9Window
	{
	public:
		static LPDIRECT3D9				MyDx9Interface;
		static LPDIRECT3DDEVICE9		MyRenderingDevice;
		static HRESULT ChangeToFullscreen(bool fullscreen);													//Fullscreen modus wechseln
		static HRESULT InitD3D(HWND hWnd);																		//DX9 initialisieren
		static VOID Cleanup();																					//Ger�t/Interface entfernen
		static VOID Render();
		static LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
		static INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow );	//Winmain ist die funktion, die nach dem Starten des Prozesses aufgerufen wird
	};
}

#endif

#include "Engine.h"



landev::Engine::Engine()
{
	landev::DX9Window::MyRenderingDevice->Clear(
}

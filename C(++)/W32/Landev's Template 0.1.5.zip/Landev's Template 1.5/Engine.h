#ifndef Engine_h
#define Engine_h

#include "d3d9.h"
#include "d3dx9shape.h"
#include "DX9Window.h"

namespace landev
{
	class Engine
	{
		static LPDIRECT3DDEVICE9* parentDevice;
		Engine();
		void RenderModel();
	};
}


#endif
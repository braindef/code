
#include "DeadFrame.h"

HWND HWnd = NULL;									// Fenster-Handle
HINSTANCE hInst = NULL;								// Main Instanz

// D3D Globals
LPDIRECT3D9						lpD3D = NULL;				// Direct3D Hauptobjekt
LPDIRECT3DDEVICE9				lpD3DDevice = NULL;			// Device Objekt 
D3DDISPLAYMODE					d3ddm;						// Display Mode
D3DPRESENT_PARAMETERS	        d3dpp;						// Anzeige Eigenschafen 


LPDIRECT3DSURFACE9				lpBackbuffer = NULL;		// Backbuffer
LPDIRECT3DSURFACE9				lpSprite = NULL;			// Surface f�r ein Sprite

D3DFORMAT						FORMAT = D3DFMT_A8R8G8B8;

POINT SpritePos;											// Position des Sprites
RECT rcSprite;												// Ein Rect fuer das Sprite

bool first=true;


//Forward declarations
bool Init(void);
bool Main(void);
void Kill(void);
void DoSomethingUseful(void);
void putPixel(int pX, int pY, DWORD pColor);

LRESULT CALLBACK WindowProc(HWND hWnd, 
						    UINT msg, 
                            WPARAM wParam, 
                            LPARAM lParam)
{
	switch(msg)
	{	
		case WM_CREATE: 
		{
			// Initialisation
			return(0);
		} break;
        
		case WM_KEYDOWN:
			if (wParam == VK_ESCAPE) PostQuitMessage ( 0 );
			break;

		case WM_DESTROY: 
		{		
			PostQuitMessage(0);
			return(0);
		} break;

		default:break;
	} 

	return (DefWindowProc(hWnd, msg, wParam, lParam));
}



int WINAPI WinMain(	HINSTANCE hinstance,
					HINSTANCE hprevinstance,
					LPSTR lpcmdline,
					int ncmdshow)
{
	WNDCLASS winclass;							// Fensterklasse
	HWND	 hWnd;								// Fenster-Handle
	MSG		 msg;								// Message-Handler

	// Fensterklasse einrichten
	winclass.style			= CS_DBLCLKS | CS_OWNDC | 
		                      CS_HREDRAW | CS_VREDRAW;
	winclass.lpfnWndProc	= WindowProc;
	winclass.cbClsExtra		= 0;
	winclass.cbWndExtra		= 0;
	winclass.hInstance		= hinstance;
	winclass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);
	winclass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	winclass.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);
	winclass.lpszMenuName	= NULL;
	winclass.lpszClassName	= L"DeadFrame";

	// Fensterklasse anmelden
	if(!RegisterClass(&winclass))
		return(0);

	// Hauptfenster wird erstellt
	if(!(hWnd = CreateWindow(L"DeadFrame",									// Fensterklasse
							 L"DeadFrame",									// Fenstertitel
							 WS_POPUP | WS_VISIBLE,
						 	 0,0,											// x ,y startposition des Fensters
							 GetSystemMetrics(SM_CXSCREEN),					// Breite
							 GetSystemMetrics(SM_CYSCREEN),					// H�he
							 NULL,
							 NULL,
							 hinstance,		
							 NULL)))
		return(0);

	HWnd = hWnd;	// Globaler Fenster-Handle
	hInst = hinstance;

	if(Init()==0)
		return 0;

	// Main Event Loop
	while(1)
	{
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{ 
	        if (msg.message == WM_QUIT)
				break;

			TranslateMessage(&msg);

			DispatchMessage(&msg);
		}    
		
		if(Main()==0)
			return 0;
	} 

	Kill();

	return(msg.wParam);
}



bool Init(void)
{

	if((lpD3D = Direct3DCreate9(D3D_SDK_VERSION))==NULL)
		return FALSE;
	
	// Fuellt die d3ddm Struktur, die uns u. a. Informationen �ber den Speicheraufbau der Grafikkarte liefert
	if(lpD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm)!=D3D_OK)
		return FALSE;

	memset(&d3dpp, 0, sizeof(d3dpp));


	d3dpp.Windowed = FALSE;							// Vollbild = TRUE
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;			// Flippen
	d3dpp.BackBufferFormat = FORMAT;      
	d3dpp.BackBufferWidth = SCREEN_WIDTH;
	d3dpp.BackBufferHeight = SCREEN_HEIGHT;
	d3dpp.BackBufferCount = 1;						// Dopplebuffering
	d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	//d3dpp.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_ONE;
	d3dpp.hDeviceWindow = HWnd;
	d3dpp.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;	//Damit der backbuffer gelockt werden kann
	
	// Unterstuetzt das Device HAL?
	if(lpD3D->CheckDeviceType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, d3ddm.Format, FALSE)==D3D_OK)
	{
			if(lpD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, HWnd,
						D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &lpD3DDevice)!=D3D_OK)
						return FALSE;  
	}
    else
	{
			if(lpD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_REF , HWnd,
						D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &lpD3DDevice)!=D3D_OK)
						return FALSE;  
	}

	// Kein Culling
	if(lpD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE)!=D3D_OK)
		return FALSE;

	// Kein Lighting
	if(lpD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE)!=D3D_OK)
		return FALSE;

	// Kein Z-Buffer
	if(lpD3DDevice->SetRenderState(D3DRS_ZENABLE, FALSE)!=D3D_OK)
		return FALSE;

	if(lpD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE)!=D3D_OK)
		return FALSE;

	// Backbuffer �bernehmen
	if(lpD3DDevice->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &lpBackbuffer)!=D3D_OK)		//3. Parameter mal NULL genommen...
		return FALSE;

	

	// Erzeugt das Surface fuer das Sprite
	//lpD3DDevice->CreateImageSurface(100, 100, FORMAT, &lpSprite);
	
	lpD3DDevice->CreateOffscreenPlainSurface(d3ddm.Width, d3ddm.Height,
    FORMAT, D3DPOOL_SYSTEMMEM, &lpSprite, NULL);


	// Bitmap wird aus Datei geladen
	D3DXLoadSurfaceFromFile(lpSprite, NULL, NULL, L"test.bmp", NULL, D3DX_FILTER_POINT, 0, NULL);



	DoSomethingUseful();


	
	//int a = 0, r = 0, g = 0, b = 0;
	//GetBitsForFormat(Format,&a,&r,&g,&b);

	// Position des Sprites
	SpritePos.x = 300;
	SpritePos.y = 300;

	// Rect Struktur wird gefuelt
	rcSprite.left = 0;
	rcSprite.top = 0;
	rcSprite.right = 100;
	rcSprite.bottom = 100;

	return 1;
}


void DoSomethingUseful(void)
{
	const int size=100;
	float PI=3.14159265359;

    float data[100][100][3];	// = new float[100][100][3];           //[x komponente +-1][y komponente +-1][Feldst�rke]
    float vector1[100][100][3]; // = new float[100][100][3];
    float vector2[100][100][3]; // = new float[size][size][3];
    float vectorSum[100][100][3]; // = new float[size][size][3];
    float x02=20;
    double maxLength=0;
    
        for(int i=1; i<size; i++)
            for(int j=1; j<size;j++)
            {   
                
                float x=i-size/2.0f;
                float y=j-size/2.0f;
                
				

                vector1[i][j][0]=cos(atan(y/(x-x02))+PI/2);
                vector1[i][j][1]=sin(atan(y/(x-x02))+PI/2);
                vector1[i][j][2]=sqrt(pow(x-x02,2)+pow(y,2));		//Betrag des Vektors
                
                vector2[i][j][0]=cos(atan(y/(x+x02))+PI/2);
                vector2[i][j][1]=sin(atan(y/(x+x02))+PI/2);
                vector2[i][j][2]=sqrt(pow(x+x02,2)+pow(y,2));
                
                
                //vectorSum[i][j][0] = 2/vector1[i][j][2]*vector1[i][j][0]+2/vector2[i][j][2]*vector2[i][j][0];
                //vectorSum[i][j][1] = 2/vector1[i][j][2]*vector1[i][j][1]+2/vector2[i][j][2]*vector2[i][j][1];
                
                vectorSum[i][j][0] = 4/vector1[i][j][2]*vector1[i][j][0]+4/vector2[i][j][2]*vector2[i][j][0];
                vectorSum[i][j][1] = 4/vector1[i][j][2]*vector1[i][j][1]+4/vector2[i][j][2]*vector2[i][j][1];
                
				float abs=sqrt(pow(vectorSum[i][j][0],2)+pow(vectorSum[i][j][1],2));

                if(maxLength<abs) maxLength=abs;
                
                //System.out.println(vectorSum[i][j][0] + " / " + vectorSum[i][j][1]);
                //data[i][j][0]=(i-data.length/2.0)/data.length;                          //
                //data[i][j][1]=(j-data.length/2.0)/data.length;                          //
                //System.out.println(">"+data[i][j][0]+"/"+data[i][j][1]);
				putPixel(i,j,(DWORD)(vectorSum[i][j][0]*10));
                
            }
}

void putPixel(int pX, int pY, DWORD pColor)
{
	D3DLOCKED_RECT rcLocked;

	lpBackbuffer->LockRect(&rcLocked, NULL, 0);
	
	unsigned int pitch = rcLocked.Pitch>>2;
    DWORD *color = (DWORD *)rcLocked.pBits;

    color[((pY+100)*pitch +pX+100) ]=pColor;

    lpBackbuffer->UnlockRect();
}


/* Original

	D3DLOCKED_RECT rcLocked;

	lpBackbuffer->LockRect(&rcLocked, NULL, 0);
	
	unsigned int pitch = rcLocked.Pitch>>2;
    DWORD *color = (DWORD *)rcLocked.pBits;

    for (DWORD y = 0; y < 300; y++)
    {
        for (DWORD x = 0; x < 300; x++)
        {
            color[((y+100)*pitch +x+100) ]=0x33ffffaa;
        }
    }

    lpBackbuffer->UnlockRect();
}
*/

/*
 *	GameMain
 */

bool Main(void)
{
	// Wurde die Escape-Taste gedrueckt?
	//if(KEY_DOWN(VK_ESCAPE))
	//	PostMessage(main_window_handle, WM_DESTROY,0,0);
	
	// Loescht den Backbuffer
	//if(lpD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0)!=D3D_OK)
	//	return FALSE;

	// Blitten
	if(lpD3DDevice->UpdateSurface(lpSprite, &rcSprite, lpBackbuffer, &SpritePos))			//CopyRects(lpSprite, &rcSprite, 1, lpBackbuffer, &SpritePos)!=D3D_OK)
		return FALSE;

	// Zeigt das Bild an
	if (first)
	{
		if(lpD3DDevice->Present(NULL, NULL, NULL, NULL)!=D3D_OK)
		return FALSE;
	}
	first=false;
		
	return 1;
}


/*
 *	GameShutdown
 */

void Kill(void)
{
	// Bevor das Programm beendet wird, wird schnell noch Aufgeraeumt
	if(lpSprite!=NULL)
		lpSprite->Release();

	if(lpBackbuffer!=NULL)
		lpBackbuffer->Release();

	if(lpD3DDevice!=NULL)
		lpD3DDevice->Release();

	if(lpD3D!=NULL)
		lpD3D->Release();
}
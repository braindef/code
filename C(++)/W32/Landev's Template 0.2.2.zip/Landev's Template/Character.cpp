/*

char c='5';
int Ziffer = c - '0';

*/

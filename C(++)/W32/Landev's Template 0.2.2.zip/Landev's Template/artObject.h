#ifndef artObject_h
#define artObject_h


#include "d3d9.h"
#include "d3dx9shape.h"
#include "DX9Window.h"
#include <vector>

//#include "FPS.h"

#include "math.h"			//sin
//#include "stdio.h"			//sprintf


namespace landev
{
	class artObject
	{
	public:

		int x;

		int initFactor;

		artObject(LPDIRECT3DDEVICE9* ParentDevice, int initFactor);
		~artObject();

		HRESULT Draw();
		HRESULT Draw(int x, int y, int width, int height);
		HRESULT Calculate();


	};

}

#endif
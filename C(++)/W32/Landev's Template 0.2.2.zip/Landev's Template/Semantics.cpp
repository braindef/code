
/* Bedingung ? Ausdruck1 : Ausrduck2

max = a > b ? a : b;

if (a > b) max = a;
else max = b;



// do while: wird mindestens einmal ausgef�hr
do
    {} 
		while (boolean)


*/

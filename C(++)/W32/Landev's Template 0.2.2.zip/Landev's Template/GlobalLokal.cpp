
/*

int a = 100;

void Methode()
{
  printf("a= %d", a);		//Globlaes a

  int a = -100;

  printf("a= %d", a);		//Lokales a

  printf("a= %d", ::a);		//Globales a



  */

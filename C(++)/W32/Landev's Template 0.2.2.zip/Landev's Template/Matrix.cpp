#include "Matrix.h"

/*
landev::Matrix::Matrix(int row, int col)
{
	A = (double**)malloc(col*sizeof(double*));
	assert(A != NULL);
	A[0] = (double*)malloc(row*col*sizeof(double));
	assert(A[0] != NULL);
	for(int=1; i<col; i++)
		A[i] = A[0] + i*row;


}


landev::Matrix::~Matrix()
{
	free(A[0]);
	free(A);
	//anstelle von free aus xyz.h delete A...
}

*/
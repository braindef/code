#ifndef Engine_h
#define Engine_h

#include <vector>
#include "math.h"			//sin
//#include "stdio.h"			//sprintf

#include "d3d9.h"
//#include "d3dx9shape.h"

#include "DX9Window.h"
//#include "FPS.h"
#include "artObject.h"



namespace landev
{
	namespace anotherNamespace
	{
		class anotherClass
		{
		};
	}

	class Engine
	{
	public:

		//Device
		static LPDIRECT3DDEVICE9* parentRenderingDevice;
		Engine(LPDIRECT3DDEVICE9* parentDevice);
		~Engine();

		//Methods and Atributes
		bool init;
		HRESULT Draw();
		HRESULT Draw(int x, int y, int width, int height);

		//References to other objects
		HRESULT HookChild(landev::artObject* child);			//allenfalls singelton nehmen
		
		//static int childrenCount;
		static std::vector<landev::artObject*> children;

		int modelStartTime;
		int modelTime;
	};
}


#endif
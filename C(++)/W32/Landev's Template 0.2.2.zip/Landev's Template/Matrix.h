#ifndef Matrix_h
#define Matrix_h

namespace landev
{
	class Matrix
	{
	public:
		double **A;
		Matrix(int row, int col);
	};
}

#endif



/*

Kommentare zur verwendung von komplizierten Pointern

int *a1;				es wird ein Pointer erstellt auf einen int (im speicher ist ist das eine adresse im heap mit einem wert)
a1 = new int;			es wird ein neuer int erzeugt und a zugewisen, a gibt die Adresse des neuen int's zur�ck
						(im heap ist nun der pointer in einem Speicher und zeigt auf einen anderen der den neuen int enth�lt)
*a1 = 123;				der Speicher f�r den int wird gewechselt, nicht aber der Pointer auf diesen Speicher

int *a2 = new int[4]	es wird ein Pointer erstellt, der auf den anfang eines feldes aus 4 int's zeigt



**A ist ein Pointer auf einen Pointer

*/

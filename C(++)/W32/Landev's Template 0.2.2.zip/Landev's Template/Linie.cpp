#include "Linie.h"

D3DXVECTOR2* Vector1 =  new D3DXVECTOR2[ 2 ]; 
LPD3DXLINE Line;

bool init=true;			//ist noch statisch ?

landev::Linie::Linie(LPDIRECT3DDEVICE9* parentDevice, int x, int y)
{
    if (init) D3DXCreateLine( *parentDevice, &Line );
	Line->SetWidth(3);
	Line->SetAntialias(true);
	
}



void landev::Linie::Draw()
{
	Draw(0,0,400,400);
	
}

void landev::Linie::Draw(int x1, int y1, int x2, int y2)
{
	Vector1[ 0 ] = D3DXVECTOR2( x1, y1 ); 
	Vector1[ 1 ] = D3DXVECTOR2( x2, y2 );
	
	Line->Begin();
	Line->Draw(Vector1, 2, 0x99ffaaaa);
	Line->End();

	//Draw();
}




#include "Text.h"



landev::Text::Text(LPDIRECT3DDEVICE9* parentDevice, int x, int y)
{

	TextString = new char[10];
	sprintf(TextString, "XXXXX");
	SetRect( &FPSRect, x, y, x+60, y+15 );        
	if( FAILED( 
		D3DXCreateFont( *parentDevice, 15, 0, FW_LIGHT, 1, FALSE, DEFAULT_CHARSET, 
					OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
					"Arial", &FPSText )
				)
		)
	return;
}

void landev::Text::Draw(int x, int y, char text[], int color)
{
	
	sprintf(TextString, "XXXXX");				//...!=0 keine DivbyZero
	FPSText->DrawText( NULL, TextString , -1, &FPSRect, DT_NOCLIP, color);	
	SetRect( &FPSRect, x, y, x+60, y+15 );
	Draw();	
}


void landev::Text::Draw()
{
	
	sprintf(TextString, "XXXXX");				//...!=0 keine DivbyZero
	FPSText->DrawText( NULL, TextString , -1, &FPSRect, DT_NOCLIP, 0xffffff00);	
	
}

void landev::Text::Draw(int x, int y)
{
	SetRect( &FPSRect, x, y, x+60, y+15 );
	Draw();
}
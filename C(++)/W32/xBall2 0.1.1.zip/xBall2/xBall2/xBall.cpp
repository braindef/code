
#include "xBall.h"
#include <stdio.h>
#include <windows.h>
#include <Commctrl.h>
#include "resource.h"
#include "K8055D_C.h"
#include "mmsystem.h"

#define DEFAULT_TIME 600
#define DEFAULT_PAUSE_TIME 120

HWND hwnd;                                                              // Dialog
HWND hDialog;



int intCurrentCard=0;
bool cardFound=false;
bool TeamA=false;
bool TeamB=false;
bool terminate=true;						//f�rs beenden

bool valid=false;

bool running=false;
int startTime=0;							//inizialer tick count
int defaultTime;							//Zeit die zur Berechnung initial verwendet wird

bool pause=false;
int globalPauseStartTime=0;					
int globalPauseTime=0;						//zeit in der die pause gedr�ckt wurde

int defaultPauseTime=0;
int localPauseStartTime=0;

bool lockInvalid=false;

//Forward declarations
void start();
void stop();
void resume();
void cont();
void clear();
void localPause();
void globalPause();



void fadeIn()
{
	if (IsDlgButtonChecked(hDialog, IDC_AdjustVolume)==0) return;
	//Beep(9000,1000);
	for(int i=0; i<=0xfff0fff0; i+=0x000f000f)
		waveOutSetVolume(0,i);
}

void fadeOut()
{
	if (IsDlgButtonChecked(hDialog, IDC_AdjustVolume)==0) return;
	//Beep(9000,1000);
	for(DWORD i=0xffffffff; i>=0x000f000f; i-=0x000f000f)
		waveOutSetVolume(0,i);
}

LRESULT CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	hDialog=hDlg;
	switch (message)
	{
			case WM_INITDIALOG:   

					
				//int intDevices;
				//intDevices=SearchDevices();					//macht noch probleme
				//waveOutSetVolume(0,0xffffffff);

				hwnd = GetDesktopWindow(); 

				if (OpenDevice(0)==-1) 
				{
					MessageBox(NULL, L"Karte nicht gefunden, Bitte Stellen Sie die Karte auf die Adresse 0 ein", L"Karte nicht gefunden", MB_OK | MB_ICONERROR);
				}
				else
				{
					cardFound=true;
					Beep(2000,50);Beep(1000,50);
					SetCounterDebounceTime(1, 0);
					ClearAllDigital();
					ClearAllAnalog();
				}
				SetDlgItemInt(hDlg, IDC_TimeDefault, DEFAULT_TIME, false);
				SetDlgItemInt(hDlg, IDC_PauseDefault, DEFAULT_PAUSE_TIME, false);
				SetTimer(hDlg, IDT_TIMER, 10, 0);
				// Window initialisation
				//MessageBox(NULL, L"Hello World", L"Hello", MB_OK | MB_ICONQUESTION);
				EnableWindow(GetDlgItem(hDlg, IDD_DIALOG), true);
			return TRUE;
		case WM_CLOSE:
//		
			return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == ID_ENDE) {    
				if (terminate) EndDialog(hDlg, LOWORD(wParam));
			}
			if (LOWORD(wParam) == IDC_TeamA) {
				if(!TeamA && !TeamB && running) 
				{
					TeamA=true;
					localPause();
				}
			}
			if (LOWORD(wParam) == IDC_TeamB) {
				if(!TeamA && !TeamB && running) 
				{
					TeamB=true;
					localPause();
				}
			}

			if (LOWORD(wParam) == IDC_INVALID)
			{
				if(TeamA || TeamB) resume();
			}		
			if (LOWORD(wParam) == IDC_VALID)
			{
				if(TeamA || TeamB) cont();
			}
			if (LOWORD(wParam) == IDC_START)					//START
			{
				fadeOut();
				start();
			}
			
			if (LOWORD(wParam) == IDC_STOP)						//STOP
			{
				stop();
			}
				
			if (LOWORD(wParam) == IDC_PAUSE)					//Pause
			{
				globalPause();
			}
			
			break;

		case WM_DESTROY :
            PostQuitMessage(0);
			ClearAllDigital();
			ClearAllAnalog();
			CloseDevice();                                              // Close the device connection (if any)
			EndDialog(hDlg, LOWORD(wParam));                            // Close the dialog
            break;
		
		case WM_TIMER:                                                  // Timer event
			if (LOWORD(wParam) == IDT_TIMER) 
			{
				LONG lngInputs = ReadAllDigital();                           // Read all digital inputs
				if(!TeamA && !TeamB) 
				{
					if(cardFound) TeamA=lngInputs & 1;
					if (TeamA) 
					{
						localPause();
					}			
					if(cardFound) TeamB=(lngInputs & 2) / 2;
					if (TeamB) 
					{
						localPause();
					}
				}
				CheckDlgButton(hDlg, IDC_TeamA, TeamA);
				if(TeamA) SetDigitalChannel(1);
				CheckDlgButton(hDlg, IDC_TeamB, TeamB);
				if(TeamB) SetDigitalChannel(2);
				SetTimer(hDlg, IDT_TIMER, 1, 0);
				if (running)
				{
					TCHAR myTimeString[16];
					int dTime=(GetTickCount()-startTime)/1000-defaultTime;
					wsprintf(myTimeString,L"%d", dTime);
					SetDlgItemText(hDlg, IDC_Timer, (LPCWSTR)myTimeString);
					int totalTime = GetDlgItemInt(hDlg, IDC_TimeDefault, NULL, false);
					if (totalTime<=dTime)
					{
						Beep(4000,100);
						Beep(3000,100);
						Beep(2000,100);
						Beep(1000,100);
						Beep(500,100);
						Beep(250,100);
						running=false;
						fadeIn();
					}
					localPauseStartTime=GetTickCount();
				}
				if (pause)
				{
					TCHAR myTimeString[16];
					int dPauseTime=(GetTickCount()-localPauseStartTime)/1000-defaultPauseTime;
					wsprintf(myTimeString,L"%d", dPauseTime);
					SetDlgItemText(hDlg, IDC_PauseTime, (LPCWSTR)myTimeString);
				}
				
				

			}
			if (LOWORD(wParam) == IDT_PAUSETIMER)
			{
				if(valid)
				{
					fadeOut();
					Beep(600,100);
					Beep(40,900);
					Beep(600,100);
					Beep(40,900);
					Beep(600,100);
					Beep(40,900);
					Beep(1200,100);
					clear();
					valid=false;
					lockInvalid=false;

				}
				
			}
			break;

      default :
            return( DefWindowProc( hDlg, message, wParam, lParam ));

	}
	return 0L;
}

void reset()
{
	running=false;
	pause=false;
}

void start()
{
	Beep(600,100);
	Beep(40,900);
	Beep(600,100);
	Beep(40,900);
	Beep(600,100);
	Beep(40,900);
	Beep(1200,100);
		
	clear();
	startTime=GetTickCount();
	running=true;
	pause=false;
	valid=false;
}

void globalPause()
{

	if (running) 
	{ 
			
		Beep(1200,100);
		Beep(40,900);
		Beep(600,100);

		running=false;
		globalPauseTime=GetTickCount();
		
		return;
	}
	if (!running) 
	{ 
		Beep(600,100);
		Beep(40,900);
		Beep(600,100);
		Beep(40,900);
		Beep(600,100);
		Beep(40,900);
		Beep(1200,100);
		
		startTime+=GetTickCount()-globalPauseTime;
		localPauseStartTime+=GetTickCount()-globalPauseTime;
		running=true;
	
		return;
	}
}

 void stop()
 {
	 running=false;
	 pause=false;
 }

void localPause()
{
	
	defaultPauseTime = GetDlgItemInt(hDialog,IDC_PauseDefault,NULL,false);
	SetTimer(hDialog, IDT_PAUSETIMER, (defaultPauseTime-3)*1000, 0);

	Beep(600,500);
	
	fadeIn();

	localPauseStartTime=GetTickCount();
	running=false;
	pause=true;
	valid=true;
}

void resume()			//invalid
{
	if(lockInvalid) return;
	fadeOut();
	Beep(600,250);
	Beep(50,100);
	Beep(600,500);
	clear();
	running=true;
	pause=false;
	localPauseStartTime=0;
	valid=false;
	
}

void cont()				//valid
{
	startTime+=defaultPauseTime*1000;
	running=false;
	pause=true;
	valid=true;
	lockInvalid=true;
	
}

void clear()
{
	TeamA=false;
	ClearDigitalChannel(1);
	TeamB=false;
	ClearDigitalChannel(2);
	// ADDENDUM
	running=true;
	pause=false;
	//defaultPauseTime=0;
	KillTimer(hDialog,IDT_PAUSETIMER);
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {



	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG), (HWND)hwnd, (DLGPROC)DialogProc);
	MessageBox(NULL, L"Beenden?", L"Beenden?", MB_OKCANCEL | MB_ICONQUESTION);
	return 0;
}

/*
void ShowVolume(void)
{
    // This is the function that can be added to the Generic Sample to
    // illustrate the use of waveOutGetVolume() and waveOutSetVolume().

    char buffer[40];
    char printbuf[80];
    UINT uRetVal, uNumDevs;
    DWORD volume;
    long lLeftVol, lRightVol;

    WAVEOUTCAPS waveCaps;

    // Make sure there is at least one
    // wave output device to work with.
    if (uNumDevs = waveOutGetNumDevs())
    {
   itoa((int)uNumDevs, buffer, 10);
   wsprintfA(printbuf, "Number of devices is %s\n", (LPSTR)buffer);
   MessageBox(GetFocus(), printbuf, "NumDevs", MB_OK);
    }

    // This sample uses a hard-coded 0 as the device ID, but retail
    // applications should loop on devices 0 through N-1, where N is the
    // number of devices returned by waveOutGetNumDevs().
    if (!waveOutGetDevCaps(0,(LPWAVEOUTCAPS)&waveCaps,
       sizeof(WAVEOUTCAPS)))

    {
   // Verify the device supports volume changes
   if(waveCaps.dwSupport & WAVECAPS_VOLUME)
   {
       // The low word is the left volume, the high word is the right.
       // Set left channel: 2000h is one-eighth volume (8192 base ten).
       // Set right channel: 4000h is quarter volume (16384 base ten).
       uRetVal = waveOutSetVolume(0, (DWORD)0x40002000UL);

       // Now get and display the volumes.
       uRetVal = waveOutGetVolume(0, (LPDWORD)&volume);

       lLeftVol = (long)LOWORD(volume);
       lRightVol = (long)HIWORD(volume);

       ltoa(lLeftVol, buffer, 10);
       wsprintf(printbuf, "Left Volume is %s\n", (LPSTR)buffer);
       MessageBox(GetFocus(), printbuf, "Left Volume", MB_OK);

       ltoa(lRightVol, buffer, 10);
       wsprintf(printbuf, "Right Volume is %s\n", (LPSTR)buffer);
       MessageBox(GetFocus(), printbuf, "Right Volume", MB_OK);

       // The low word is the left volume, the high word is the right.
       // Set left channel: 8000h is half volume (32768 base ten).
       // Set right channel: 4000h is quarter volume (16384 base ten).
       uRetVal = waveOutSetVolume(0, (DWORD)0x40008000UL);

       // Now get and display the volumes.
       uRetVal = waveOutGetVolume(0, (LPDWORD)&volume);

       lLeftVol = (long)LOWORD(volume);
       lRightVol = (long)HIWORD(volume);

       ltoa(lLeftVol, buffer, 10);
       wsprintf(printbuf, "Left Volume is %s\n", (LPSTR)buffer);
       MessageBox(GetFocus(), printbuf, "Left Volume", MB_OK);

       ltoa(lRightVol, buffer, 10);
       wsprintf(printbuf, "Right Volume is %s\n", (LPSTR)buffer);
       MessageBox(GetFocus(), printbuf, "Right Volume", MB_OK);

   }
    }
}*/
	
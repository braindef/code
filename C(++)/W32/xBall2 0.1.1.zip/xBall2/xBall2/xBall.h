#include <stdio.h>
#include <windows.h>
#include <Commctrl.h>
#include "resource.h"
#include "K8055D_C.h"





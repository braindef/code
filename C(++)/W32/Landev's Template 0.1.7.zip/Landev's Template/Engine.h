#ifndef Engine_h
#define Engine_h

#include "d3d9.h"
#include "d3dx9shape.h"
#include "DX9Window.h"

namespace landev
{
	class Engine
	{
	public:
		static LPDIRECT3DDEVICE9* parentDevice;
		Engine();
		HRESULT RenderModel();
		HRESULT RenderModel(int i);
	};
}


#endif
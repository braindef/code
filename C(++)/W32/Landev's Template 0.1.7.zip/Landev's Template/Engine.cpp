#include "Engine.h"
#include "math.h"
#include "stdio.h"

ID3DXFont*          MyFont = NULL;
RECT rc; 
int MyTime = NULL;
float yCord = NULL;
bool init2=true;
int StartTime2=0;

float Pi=3.14159265;

landev::Engine::Engine()
{
	StartTime2=GetTickCount();
}

HRESULT landev::Engine::RenderModel()
{
		if (init2) //Wir wollen das Font-Objekt nur einmal erstellen!
			if( FAILED( D3DXCreateFont( landev::DX9Window::MyRenderingDevice, 30, 0, FW_LIGHT, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         "Arial", &MyFont ) ) );
        
        
		//LPCSTR = const char * und LPSTR = char *
		
		char MyTimeString[10];
		MyTime = GetTickCount();
		int dTime = (MyTime-StartTime2);
		

		//int MySin(float startPhi, float stopPhi,

		SetRect( &rc,(dTime/10)%700-60,200-abs(100*(sin((float)dTime/1800*Pi))), 0, 0 );        
		
		sprintf(MyTimeString,"%d",dTime);
		MyFont->DrawText( NULL, MyTimeString , -1, &rc, DT_NOCLIP, 0xff0000ff);
		//MyFont->Release();
		init2=false;

return S_OK;
}

HRESULT landev::Engine::RenderModel(int i)
{
		if (init2) //Wir wollen das Font-Objekt nur einmal erstellen!
			if( FAILED( D3DXCreateFont( landev::DX9Window::MyRenderingDevice, 30, 0, FW_LIGHT, 1, FALSE, DEFAULT_CHARSET, 
                         OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                         "Arial", &MyFont ) ) );
        
        
		//LPCSTR = const char * und LPSTR = char *
		
		char MyTimeString[10];
		MyTime = GetTickCount();
		int dTime = (MyTime-StartTime2);
		

		//int MySin(float startPhi, float stopPhi,

		SetRect( &rc,(dTime/10)%700-60,i+200-abs(100*(sin((float)dTime/1800*Pi))), 0, 0 );        
		
		sprintf(MyTimeString,"%d",dTime);
		
		MyFont->DrawText( NULL, MyTimeString , -1, &rc, DT_NOCLIP, 0xff0000ff);
		//MyFont->Release();
		init2=false;

return S_OK;
}

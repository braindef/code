// DlgBackgroundArtDecoDlg.h : Header-Datei
//

#if !defined(AFX_DLGBACKGROUNDARTDecoDLG_H__06739D18_22AF_4E98_88D4_B650EC41993A__INCLUDED_)
#define AFX_DLGBACKGROUNDARTDecoDLG_H__06739D18_22AF_4E98_88D4_B650EC41993A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#include "DirectXDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgBackgroundArtDecoDlg Dialogfeld

class CDlgBackgroundArtDecoDlg : public CDirectXDialog
{
friend class _LockGuard;
// Konstruktion
public:
	CDlgBackgroundArtDecoDlg(CWnd* pParent = NULL);	// Standard-Konstruktor
// Dialogfelddaten
	//{{AFX_DATA(CDlgBackgroundArtDecoDlg)
	enum { IDD = IDD_DLGBACKGROUNDARTDECO_DIALOG };
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CDlgBackgroundArtDecoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	virtual void displayFrame();
	virtual HRESULT initDirectDraw();
	virtual void freeDirectXResources();
	CSurface* g_pTextSurface;			


	HICON m_hIcon;
	char zoom;
	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CDlgBackgroundArtDecoDlg	)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_DLGBACKGROUNDARTDecoDLG_H__06739D18_22AF_4E98_88D4_B650EC41993A__INCLUDED_)

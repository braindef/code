// DlgBackgroundArtDecoDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "DlgBackgroundArtDeco.h"
#include "DlgBackgroundArtDecoDlg.h"
#include <stdio.h>
#include <sys/timeb.h>
#include <time.h>
#include "dxutil.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg-Dialogfeld f�r Anwendungsbefehl "Info"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialogfelddaten
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// Keine Nachrichten-Handler
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBackgroundArtDecoDlg Dialogfeld

CDlgBackgroundArtDecoDlg::CDlgBackgroundArtDecoDlg(CWnd* pParent /*=NULL*/)
	: CDirectXDialog(CDlgBackgroundArtDecoDlg::IDD, pParent), zoom(17)
{
	//{{AFX_DATA_INIT(CDlgBackgroundArtDecoDlg)
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDlgBackgroundArtDecoDlg::freeDirectXResources()
{
	CDirectXDialog::freeDirectXResources();
	SAFE_DELETE(g_pTextSurface);
}
void CDlgBackgroundArtDecoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDirectXDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgBackgroundArtDecoDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgBackgroundArtDecoDlg, CDirectXDialog)
	//{{AFX_MSG_MAP(CDlgBackgroundArtDecoDlg)
	ON_WM_PAINT()
	ON_WM_SYSCOMMAND()
	ON_WM_QUERYDRAGICON()
	ON_WM_MOUSEWHEEL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgBackgroundArtDecoDlg Nachrichten-Handler

BOOL CDlgBackgroundArtDecoDlg::OnInitDialog()
{
	CDirectXDialog::OnInitDialog();

	// Hinzuf�gen des Men�befehls "Info..." zum Systemmen�.

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{	
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden

	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}

HRESULT CDlgBackgroundArtDecoDlg::initDirectDraw()
{
	CDirectXDialog::initDirectDraw();
	HRESULT hr;
    if( FAILED(hr = g_pDisplay.CreateSurfaceFromText( &g_pTextSurface, NULL, "__________", 
                                                        RGB(0,0,0), RGB(255, 255, 0) ) ) )
	{
		AfxMessageBox("Failed creating Text Surface");
		return hr;
	}

	return DD_OK;
}
void CDlgBackgroundArtDecoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDirectXDialog::OnSysCommand(nID, lParam);
	}
}


void CDlgBackgroundArtDecoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
		CDirectXDialog::OnPaint();
}

// Die Systemaufrufe fragen den Cursorform ab, die angezeigt werden soll, w�hrend der Benutzer
//  das zum Symbol verkleinerte Fenster mit der Maus zieht.
HCURSOR CDlgBackgroundArtDecoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


#define IS_IT_WORTH_IT


void CDlgBackgroundArtDecoDlg::displayFrame()
{
	CRect rect; GetClientRect(rect);

	int width = rect.Width() / 2;
	int height = rect.Height() / 2;

	DWORD starttime,stoptime;


	starttime = GetTickCount();
	{
		g_pDisplay.Clear();
		CDirectXLockGuard lock(this);

#if defined(IS_IT_WORTH_IT)

		setPixelPTR _setPixel = setPixel;
		int x, y, c, z = zoom;
		_asm
		{
			mov edx, width
loop1:		mov ebx, height
loop2:		mov eax, edx;	//color = (x*x+y*y)
			imul eax, eax;
			mov ecx, ebx;
			imul ecx, ecx;
			add eax, ecx;
			imul eax, eax;	//color = color*color;

			mov ecx, z;		//zoom
			sar eax, cl;

			and eax, 0xFF;
			mov cl, al;
			and cl, 0x80;	//if (color >= 128) color = color - 127;
			jz weiter;
			xor eax, 0x7F;

weiter:		shl eax, 8+1;
			
			//Backup
			mov x, edx;
			mov y, ebx;
			mov c, eax;
						
			push eax;		//color			
			mov eax, ebx;	//y
			add eax, height;
			push eax;			
			mov eax, edx;	//x
			add eax, width;
			push eax;			
			mov ecx, this;	//this-call of member function pointer
			call _setPixel;

			mov eax, c;		//color			
			push eax;
			mov eax, y;		//y
			add eax, height;
			push eax;			
			mov eax, width;	//x
			sub eax, x;
			push eax;			
			mov ecx, this;	//this-call of member function pointer
			call _setPixel;

			mov eax, c;		//color			
			push eax;
			mov eax, height;//y
			sub eax, y;
			push eax;			
			mov eax, width;	//x
			sub eax, x;
			push eax;			
			mov ecx, this;	//this-call of member function pointer
			call _setPixel;

			mov eax, c;		//color			
			push eax;
			mov eax, height;//y
			sub eax, y;
			push eax;			
			mov eax, x;		//x
			add eax, width;
			push eax;			
			mov ecx, this;	//this-call of member function pointer
			call _setPixel;


			//Reload
			mov edx, x;
			mov ebx, y;			

			sub ebx, 1
			jge loop2
			sub edx, 1
			jge loop1		
		}
#else		
		for (long x = 0; x < width; x++)
			for (long y = 0; y < height; y++)
			{
				long g = x*x + y*y;
				g = g * g;
				
				g = g >> zoom;
			
				g = g & 0xFf;
				if (g & 0x80) // if (g > 0x7f) g = 0x7f - g;
					g = 0x7f ^ g;

				g = g << 1;
//				g = g > 255? 255 : 0;
				
				(this->*setPixel)(width + x, height + y,RGBA_MAKE(g,0,0,0));
				(this->*setPixel)(width - x, height + y,RGBA_MAKE(0,g,0,0));
				(this->*setPixel)(width + x, height - y,RGBA_MAKE(0,0,g,0));
				(this->*setPixel)(width - x, height - y,RGBA_MAKE(g,g,g,0));
			}
		
#endif
	}
	stoptime = GetTickCount();

	char buffer[128];
	sprintf(buffer, "time: %4dms", stoptime - starttime);
	g_pTextSurface->DrawText(NULL, buffer, 0, 0, RGB(0,0,0), RGB(255,255,0));
	g_pDisplay.Blt(20, 20, g_pTextSurface, NULL);

	CDialog::OnPaint();
}




BOOL CDlgBackgroundArtDecoDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	if (zDelta > 0)
		zoom = (zoom + 1) & 0x1f;
	else
		zoom = (zoom - 1) & 0x1f;

	paintFrame();

	return CDirectXDialog::OnMouseWheel(nFlags, zDelta, pt);
}

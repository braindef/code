/************************************************************
*************************************************************
** Microsoft Visual C++ Project for the K8055 USB I/O Card **
**                                                         **
**                  Copyright Velleman 2005                **
**                      www.Velleman.be                    **
**                                                         **
**                                                         **
**                                                         **
**                       Developed by                      **
**                      RE-Applications                    **
**                  www.RE-Applications.be                 **
*************************************************************
*************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

#define FUNCTION __declspec(dllexport)

FUNCTION long __stdcall OpenDevice(long CardAddress);
int FUNCTION __stdcall CloseDevice();
FUNCTION long __stdcall ReadAnalogChannel(long Channel);
int FUNCTION __stdcall ReadAllAnalog(long *Data1, long *Data2);
int FUNCTION __stdcall OutputAnalogChannel(long Channel, long Data);
int FUNCTION __stdcall OutputAllAnalog(long Data1, long Data2);
int FUNCTION __stdcall ClearAnalogChannel(long Channel); 
int FUNCTION __stdcall ClearAllAnalog();
int FUNCTION __stdcall SetAnalogChannel(long Channel); 
int FUNCTION __stdcall SetAllAnalog();
int FUNCTION __stdcall WriteAllDigital(long Data);
int FUNCTION __stdcall ClearDigitalChannel(long Channel);
int FUNCTION __stdcall ClearAllDigital();
int FUNCTION __stdcall SetDigitalChannel(long Channel);
int FUNCTION __stdcall SetAllDigital();
FUNCTION bool __stdcall ReadDigitalChannel(long Channel);
FUNCTION long __stdcall ReadAllDigital();
FUNCTION long __stdcall ReadCounter(long CounterNr);
int FUNCTION __stdcall ResetCounter(long CounterNr);
int FUNCTION __stdcall SetCounterDebounceTime(long CounterNr, long DebounceTime);

int FUNCTION __stdcall Version();
FUNCTION long __stdcall SearchDevices();
FUNCTION long __stdcall SetCurrentDevice(long lngCardAddress);

#ifdef __cplusplus
}
#endif




#ifndef Engine_h
#define Engine_h

#include "d3d9.h"
#include "d3dx9shape.h"
#include "DX9Window.h"

#include "math.h"			//sin
#include "stdio.h"			//sprintf

namespace landev
{
	class Engine
	{
	public:
		bool init;
		int StartTime;
		Engine(LPDIRECT3DDEVICE9* parentDevice);
		HRESULT RenderModel();
		HRESULT RenderModel(int i);
	};
}


#endif
#include "Engine.h"

LPDIRECT3DDEVICE9* parentRenderingDevice;

landev::Engine::Engine(LPDIRECT3DDEVICE9* parentDevice)
{
	init=true;
	StartTime=GetTickCount();
	parentRenderingDevice = parentDevice;
}

HRESULT landev::Engine::RenderModel()
{
	//Hier die Szenen hinzuf�gen
	init=false;
	return S_OK;
}


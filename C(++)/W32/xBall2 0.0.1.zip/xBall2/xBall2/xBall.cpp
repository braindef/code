
#include "xBall.h"
#include <stdio.h>
#include <windows.h>
#include <Commctrl.h>
#include "resource.h"
#include "K8055D_C.h"

#define DEFAULT_TIME 30
#define DEFAULT_PAUSE_TIME 10

HWND hwnd;                                                              // Dialog
RECT rc, rcDlg, rcOwner; 



int intCurrentCard=0;
bool cardFound=false;
bool TeamA=false;
bool TeamB=false;
bool terminate=true;						//f�rs beenden

bool running=false;
int startTime=0;							//inizialer tick count
int defaultTime;							//Zeit die zur Berechnung initial verwendet wird

bool pause=false;
int globalPauseStartTime=0;					
int globalPauseTime=0;						//zeit in der die pause gedr�ckt wurde

int localPauseTime=0;


LRESULT CALLBACK DialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
			case WM_INITDIALOG:   
				//int intDevices;
				//intDevices=SearchDevices();					//macht noch probleme
				
				
				hwnd = GetDesktopWindow(); 

				/*
				GetWindowRect(hwnd, &rcOwner); 
				GetWindowRect(hDlg, &rcDlg); 
				CopyRect(&rc, &rcOwner); 

				OffsetRect(&rcDlg, -rcDlg.left, -rcDlg.top); 
				OffsetRect(&rc, -rc.left, -rc.top); 
				OffsetRect(&rc, -rcDlg.right, -rcDlg.bottom); 

				SetWindowPos(hDlg, HWND_TOP, rcOwner.left + (rc.right / 2), rcOwner.top + (rc.bottom / 2), 0, 0, SWP_NOSIZE); 
   
				SetFocus(GetDlgItem(hDlg, IDD_DIALOG)); 
*/
				if (OpenDevice(0)==-1) 
				{
					MessageBox(NULL, L"Karte nicht gefunden, Bitte Stellen Sie die Karte auf die Adresse 0 ein", L"Karte nicht gefunden", MB_OK | MB_ICONERROR);
				}
				else
				{
					cardFound=true;
					Beep(2000,50);Beep(1000,50);
					SetCounterDebounceTime(1, 0);
					ClearAllDigital();
					ClearAllAnalog();
				}
				SetDlgItemInt(hDlg, IDC_TimeDefault, DEFAULT_TIME, false);
				SetDlgItemInt(hDlg, IDC_PauseDefault, DEFAULT_PAUSE_TIME, false);
				SetTimer(hDlg, IDT_TIMER, 10, 0);
				// Window initialisation
				//MessageBox(NULL, L"Hello World", L"Hello", MB_OK | MB_ICONQUESTION);
				EnableWindow(GetDlgItem(hDlg, IDD_DIALOG), true);
			return TRUE;
		case WM_CLOSE:
//		
			return TRUE;

		case WM_COMMAND:
			if (LOWORD(wParam) == ID_ENDE) {    
				if (terminate) EndDialog(hDlg, LOWORD(wParam));
			}
			if (LOWORD(wParam) == IDC_TeamA) {
				if(!TeamA && !TeamB) TeamA=true;
			}
			if (LOWORD(wParam) == IDC_TeamB) {
				if(!TeamA && !TeamB) TeamB=true;
			}
			if (LOWORD(wParam) == IDC_INVALID)
			{
				TeamA=false;
				ClearDigitalChannel(1);
				TeamB=false;
				ClearDigitalChannel(2);
				localPauseTime=0;
			}
			if (LOWORD(wParam) == IDC_START)					//START
			{
				defaultTime=GetDlgItemInt(hDlg, IDC_TimeDefault, NULL, false);
				startTime=GetTickCount();
				running=true;
			}
			
			if (LOWORD(wParam) == IDC_STOP)						//STOP
			{
				running=false;
			}
				
			if (LOWORD(wParam) == IDC_PAUSE)					//Pause
			{
				if (running) 
				{ 
					running=false;
					globalPauseTime=GetTickCount();
					break;
				}
				if (!running) 
				{ 
					startTime+=GetTickCount()-globalPauseTime;
					running=true;
					break;
				}
			}
			
			break;

		case WM_DESTROY :
            PostQuitMessage(0);
			ClearAllDigital();
			ClearAllAnalog();
			CloseDevice();                                              // Close the device connection (if any)
			EndDialog(hDlg, LOWORD(wParam));                            // Close the dialog
            break;
		
		case WM_TIMER:                                                  // Timer event
			if (LOWORD(wParam) == IDT_TIMER) 
			{
				LONG lngInputs = ReadAllDigital();                           // Read all digital inputs
				if(!TeamA && !TeamB) 
				{
					TeamA=lngInputs & 1;
					localPauseTime = GetDlgItemInt(hDlg,IDT_PAUSETIMER,NULL,false);
					SetTimer(hDlg, IDT_PAUSETIMER, localPauseTime*1000, 0);
					pause=true;
				}
				
				if(!TeamA && !TeamB)
				{
					TeamB=(lngInputs & 2) / 2;
					localPauseTime = GetDlgItemInt(hDlg,IDT_PAUSETIMER,NULL,false);
					SetTimer(hDlg, IDT_PAUSETIMER, localPauseTime*1000, 0);
					pause=true;
				}
				CheckDlgButton(hDlg, IDC_TeamA, TeamA);
				if(TeamA) SetDigitalChannel(1);
				CheckDlgButton(hDlg, IDC_TeamB, TeamB);
				if(TeamB) SetDigitalChannel(2);
				SetTimer(hDlg, IDT_TIMER, 1, 0);
				if (running)
				{
					TCHAR myTimeString[16];
					int dTime=(GetTickCount()-startTime)/1000-defaultTime;
					wsprintf(myTimeString,L"%d", dTime);
					SetDlgItemText(hDlg, IDC_Timer, (LPCWSTR)myTimeString);
					
				}
			}
			if (LOWORD(wParam) == IDT_PAUSETIMER)
			{
				startTime-=localPauseTime*1000;
			}
			break;

      default :
            return( DefWindowProc( hDlg, message, wParam, lParam ));

	}
	return 0L;
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {


	DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG), (HWND)hwnd, (DLGPROC)DialogProc);
	MessageBox(NULL, L"Beenden?", L"Beenden?", MB_OKCANCEL | MB_ICONQUESTION);
	return 0;
}

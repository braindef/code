//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by xBall2.rc
//
#define IDD_DIALOG                      101
#define IDB_BITMAP1                     105
#define IDB_BITMAP2                     107
#define IDB_VIPERS                      107
#define IDC_TeamA                       1001
#define IDC_TeamA2                      1002
#define IDC_TeamB                       1002
#define IDC_VALID                       1003
#define IDC_INVALID                     1004
#define IDC_Timer                       1005
#define IDC_Hintergrund                 1006
#define IDC_START                       1006
#define IDC_PauseTime                   1007
#define IDC_AdjustVolume                1008
#define IDC_PauseDefault                1009
#define ID_ENDE                         1010
#define IDT_TIMER                       1011
#define IDC_TimeDefault                 1011
#define IDC_STOP                        1012
#define IDC_PAUSE                       1013
#define IDT_PAUSETIMER					1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

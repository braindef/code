
#include "DeadFrame.h"



HWND HWnd = NULL;									// Fenster-Handle
HINSTANCE hInst = NULL;								// Main Instanz

// D3D Globals
LPDIRECT3D9						lpD3D = NULL;				// Direct3D Hauptobjekt
LPDIRECT3DDEVICE9				lpD3DDevice = NULL;			// Device Objekt 
D3DDISPLAYMODE					d3ddm;						// Display Mode
D3DPRESENT_PARAMETERS	        d3dpp;						// Anzeige Eigenschafen 


LPDIRECT3DSURFACE9				lpBackbuffer = NULL;		// Backbuffer
LPDIRECT3DSURFACE9				lpSprite = NULL;			// Surface f�r ein Sprite

D3DFORMAT						FORMAT = D3DFMT_A8R8G8B8;

POINT SpritePos;											// Position des Sprites
RECT rcSprite;												// Ein Rect fuer das Sprite

bool first=true;

FILE *pFile;

//Forward declarations
bool Init(void);
bool Main(void);
void Kill(void);
void DoSomethingUseful(void);
void lockSprite();
void putPixel(int pX, int pY, DWORD pColor);
void unlockSprite();
void putPixelToLockedSprite(int pX, int pY, DWORD pColor);


LRESULT CALLBACK WindowProc(HWND hWnd, 
						    UINT msg, 
                            WPARAM wParam, 
                            LPARAM lParam)
{
	switch(msg)
	{	
		case WM_CREATE: 
		{
			// Initialisation
			return(0);
		} break;
        
		case WM_KEYDOWN:
			if (wParam == VK_ESCAPE) PostQuitMessage ( 0 );
			break;

		case WM_DESTROY: 
		{		
			PostQuitMessage(0);
			return(0);
		} break;

		default:break;
	} 

	return (DefWindowProc(hWnd, msg, wParam, lParam));
}



int WINAPI WinMain(	HINSTANCE hinstance,
					HINSTANCE hprevinstance,
					LPSTR lpcmdline,
					int ncmdshow)
{
	WNDCLASS winclass;							// Fensterklasse
	HWND	 hWnd;								// Fenster-Handle
	MSG		 msg;								// Message-Handler

	// Fensterklasse einrichten
	winclass.style			= CS_DBLCLKS | CS_OWNDC | 
		                      CS_HREDRAW | CS_VREDRAW;
	winclass.lpfnWndProc	= WindowProc;
	winclass.cbClsExtra		= 0;
	winclass.cbWndExtra		= 0;
	winclass.hInstance		= hinstance;
	winclass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);
	winclass.hCursor		= LoadCursor(NULL, IDC_ARROW);
	winclass.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);
	winclass.lpszMenuName	= NULL;
	winclass.lpszClassName	= L"DeadFrame";

	// Fensterklasse anmelden
	if(!RegisterClass(&winclass))
		return(0);

	// Hauptfenster wird erstellt
	if(!(hWnd = CreateWindow(L"DeadFrame",									// Fensterklasse
							 L"DeadFrame",									// Fenstertitel
							 WS_EX_OVERLAPPEDWINDOW | WS_VISIBLE,							// WS_POPUP | WS_VISIBLE,
						 	 0,0,											// x ,y startposition des Fensters
							 GetSystemMetrics(SM_CXSCREEN),					// Breite
							 GetSystemMetrics(SM_CYSCREEN),					// H�he
							 NULL,
							 NULL,
							 hinstance,		
							 NULL)))
		return(0);

	HWnd = hWnd;	// Globaler Fenster-Handle
	hInst = hinstance;
	
	pFile = fopen("DeadFrame.log", "w");
	fprintf(pFile, "Logfile\n");
	fprintf(pFile, "-------\n");

	if(Init()==0)
		return 0;

	// Main Event Loop
	while(1)
	{
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{ 
	        if (msg.message == WM_QUIT)
				break;

			TranslateMessage(&msg);

			DispatchMessage(&msg);
		}    
		
		if(Main()==0)
			return 0;
	} 
	fprintf(pFile, "Killing Device\n");
	Kill();
	fprintf(pFile, "END\n");
	fclose(pFile);

	return(msg.wParam);
}



bool Init(void)
{

	if((lpD3D = Direct3DCreate9(D3D_SDK_VERSION))==NULL)
	{
		fprintf(pFile, "Direct3DCreate9 Failed\n");
		return FALSE;
	}

	// Fuellt die d3ddm Struktur, die uns u. a. Informationen �ber den Speicheraufbau der Grafikkarte liefert
	if(lpD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm)!=D3D_OK)
	{
		fprintf(pFile, "GetAdapterDisplayMode Failed\n");
		return FALSE;
	}

	memset(&d3dpp, 0, sizeof(d3dpp));


	d3dpp.Windowed = TRUE;							// Vollbild = TRUE
	d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;			// Flippen
	d3dpp.BackBufferFormat = FORMAT;      
	d3dpp.BackBufferWidth = SCREEN_WIDTH;
	d3dpp.BackBufferHeight = SCREEN_HEIGHT;
	d3dpp.BackBufferCount = 1;						// Dopplebuffering
	//d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	//d3dpp.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_ONE;
	d3dpp.hDeviceWindow = HWnd;
	d3dpp.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;	//Damit der backbuffer gelockt werden kann
	
	// Unterstuetzt das Device HAL?
	if(lpD3D->CheckDeviceType(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format, d3ddm.Format, FALSE)==D3D_OK)
	{
		fprintf(pFile, "Using D3DDEVTYPE_HAL (Hardware Acceleration)\n");
			if(lpD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, HWnd,
						D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &lpD3DDevice)!=D3D_OK)
			{
						fprintf(pFile, "CreateDevice Failed\n");
						return FALSE;  
			}
	}
    else
	{
		fprintf(pFile, "Using D3DDEVTYPE_REF (Software Emulation)\n");
			if(lpD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_REF , HWnd,
						D3DCREATE_SOFTWARE_VERTEXPROCESSING, &d3dpp, &lpD3DDevice)!=D3D_OK)
			{			
				fprintf(pFile, "CreateDevice Failed\n");
						return FALSE;  
			}
	}

	// Kein Culling
	if(lpD3DDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE)!=D3D_OK)
		return FALSE;

	// Kein Lighting
	if(lpD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE)!=D3D_OK)
		return FALSE;

	// Kein Z-Buffer
	if(lpD3DDevice->SetRenderState(D3DRS_ZENABLE, FALSE)!=D3D_OK)
		return FALSE;

	if(lpD3DDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE)!=D3D_OK)
		return FALSE;

	// Backbuffer �bernehmen
	if(lpD3DDevice->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &lpBackbuffer)!=D3D_OK)		//3. Parameter mal NULL genommen...
		return FALSE;

	

	// Erzeugt das Surface fuer das Sprite
	//lpD3DDevice->CreateImageSurface(100, 100, FORMAT, &lpSprite);
	
	lpD3DDevice->CreateOffscreenPlainSurface(d3ddm.Width, d3ddm.Height,
    FORMAT, D3DPOOL_SYSTEMMEM, &lpSprite, NULL);


	// Bitmap wird aus Datei geladen
	//D3DXLoadSurfaceFromFile(lpSprite, NULL, NULL, L"test.bmp", NULL, D3DX_FILTER_POINT, 0, NULL);


	


	
	//int a = 0, r = 0, g = 0, b = 0;
	//GetBitsForFormat(Format,&a,&r,&g,&b);

	// Position des Sprites
	SpritePos.x = 0;
	SpritePos.y = 0;

	// Rect Struktur wird gefuelt
	rcSprite.left = 0;
	rcSprite.top = 0;
	rcSprite.right = 800;
	rcSprite.bottom = 600;

	return 1;
}

float I=1.0f;	

void DoSomethingUseful(void)
{

	//lockSprite();

	const int size=600;						//Hier musste beim linker mehr stack angegeben werden mit /STACK:10000000
	float PI=3.14159265359;

    static float vector1[size][size][3];			//Erstes Vektorfeld
    static float vector2[size][size][3];			//Zweites Vektorfeld
    
	//float I=1.0f;							//Strom der Leiter
	float zoom=30000.0f;					//Zoomfaktor
    
    		for(int i=1; i<size; i++)
            for(int j=1; j<size;j++)
            {								
				/* ALT: atan liefert nur werte von -PI/2 bis PI/2 deshalb der Fehler mit dem Balken quer durch
				
				//Danke an S. M�ller f�r das debuggen

				float x=(i-size/2.0f)/zoom;	//Leiter in den mittelpunkt setzen und heranzoomen
                float y=(j-size/2.0f)/zoom;
                
				
				vector1[i][j][2]=I/2/PI/sqrt(pow(x,2)+pow(y,2));			//Betrag der Magnetischen feldst�rke H=I/(2*PI*r)
                vector1[i][j][0]=-sin(atan(y/(x)))*vector1[i][j][2];		//x-Komponente * Betrag
                vector1[i][j][1]=cos(atan(y/(x)))*vector1[i][j][2];			//y-Komponente * Betrag
                
				vector2[i][j][2]=-I/2/PI/sqrt(pow(x,2)+pow(y,2));		
                vector2[i][j][0]=-sin(atan(y/(x)))*vector2[i][j][2];
                vector2[i][j][1]=cos(atan(y/(x)))*vector2[i][j][2];
				*/
				
				
				

                float x = (i - size / 2.0) / zoom;     //Leiter in den mittelpunkt setzen und heranzoomen
                float y = (j - size / 2.0) / zoom;

                float r = sqrt(x*x + y*y);				
                float H1 = I / ( 2.0 * PI * r);
                float H2 = -H1;

                vector1[i][j][0] = -y / r * H1;			//sin(phi)=y/r
                vector1[i][j][1] = x / r * H1;
                vector1[i][j][2] = H1;

                vector2[i][j][0] = -y / r * H2;
                vector2[i][j][1] = x / r * H2;
                vector2[i][j][2] = H2;
				
            }

			float u;
			float v;
			float a;

			for(int i=0; i<size-50; i++)	//darstellen von Feld1 + Feld2 um 50 Pixel versetzt
				for(int j=0; j<size; j++)
				{
					u=vector1[i][j][0]+vector2[i+40][j][0];			
					v=vector1[i][j][1]+vector2[i+40][j][1];
					a=sqrt(u*u+v*v);
					//putPixel(i,j,(DWORD)(a));			// durch 200 damit die Farbskala in etwa stimmt
					putPixelToLockedSprite(i,j,(DWORD)(a));
				}
		//unlockSprite();
			
}

unsigned int pitch;
DWORD *color;

void lockSprite()
{
	D3DLOCKED_RECT rcLocked;

	lpSprite->LockRect(&rcLocked, NULL, 0);
	
	pitch = rcLocked.Pitch>>2;
    color = (DWORD *)rcLocked.pBits;
}


void putPixel(int pX, int pY, DWORD pColor)			//Rutine um direckt in den Specher des Surfaces zu Rendern
{
	
    color[((pY)*pitch +pX+100) ]=pColor;

    
}
void unlockSprite()
{
	lpSprite->UnlockRect();
}

void putPixelToLockedSprite(int pX, int pY, DWORD pColor)			//Rutine um direckt in den Specher des Surfaces zu Rendern
{
	D3DLOCKED_RECT rcLocked;

	lpSprite->LockRect(&rcLocked, NULL, 0);
	
	pitch = rcLocked.Pitch>>2;
    DWORD *color = (DWORD *)rcLocked.pBits;

    color[((pY)*pitch +pX+100) ]=pColor;

    lpSprite->UnlockRect();
}


/* Original

	D3DLOCKED_RECT rcLocked;

	lpBackbuffer->LockRect(&rcLocked, NULL, 0);
	
	unsigned int pitch = rcLocked.Pitch>>2;
    DWORD *color = (DWORD *)rcLocked.pBits;

    for (DWORD y = 0; y < 300; y++)
    {
        for (DWORD x = 0; x < 300; x++)
        {
            color[((y+100)*pitch +x+100) ]=0x33ffffaa;
        }
    }

    lpBackbuffer->UnlockRect();
}
*/


bool Main(void)
{
	//if (first)	//Da wir nur eine Bild rendern wollen machen wir das nur das erste mal
	I=sin((float)GetTickCount()/1000);

	//fprintf(pFile, "Starting Calculation and Rendering\n");
	DoSomethingUseful();
	{	
		if(lpD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 1.0f, 0)!=D3D_OK)
	 	return FALSE;

		// Blitten
		if(lpD3DDevice->UpdateSurface(lpSprite, &rcSprite, lpBackbuffer, &SpritePos))			//CopyRects(lpSprite, &rcSprite, 1, lpBackbuffer, &SpritePos)!=D3D_OK)
		return FALSE;
		
		if(lpD3DDevice->Present(NULL, NULL, NULL, NULL)!=D3D_OK)
		return FALSE;
	}
	first=false;
		
	return 1;
}



void Kill(void)
{
	// Bevor das Programm beendet wird, wird schnell noch Aufgeraeumt
	if(lpSprite!=NULL)
		lpSprite->Release();

	if(lpBackbuffer!=NULL)
		lpBackbuffer->Release();

	if(lpD3DDevice!=NULL)
		lpD3DDevice->Release();

	if(lpD3D!=NULL)
		lpD3D->Release();
}